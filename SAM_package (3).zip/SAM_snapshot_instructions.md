# Schott Altitude Marketing Snapshot Instructions

Welcome to your pre‑built **Schott Altitude Marketing (SAM)** automation snapshot. This package contains everything you need to run an AI‑powered marketing engine that generates leads, engages customers and manages your reputation automatically.

---

## 📦 What’s Included

| Component                    | Purpose                                                                 | Notes |
|-----------------------------|-------------------------------------------------------------------------|------|
| **SAM_Snapshot.json**        | HighLevel snapshot file containing all workflows, triggers, forms and pipelines ready for import. | Use this to restore the entire snapshot in your HighLevel account. |
| **Media_Library/**            | Folder containing your polished AI welcome video (45 seconds), two teaser clips (15 seconds each), five vertical ads, branded social images, and your LinkedIn headshot. | These assets are automatically loaded into your HighLevel media library and used in posts, ads and automations. |
| **Posting_Calendar.csv**     | Backup of your preloaded 90‑day posting plan (Google Business Profile + social). | The CSV is for your reference; the posts are already scheduled in the snapshot. |
| **README_Launch_Checklist.pdf** | A concise, step‑by‑step guide to import the snapshot, activate workflows and test the system. | Refer to this after importing to ensure everything is working as expected. |

Your snapshot also includes:

- **AI‑voiced calls and voicemails** using Jason’s polished voice clone.
- **Dynamic lead capture forms** that route new leads via SMS to **303‑513‑7795** and email to **jason@schottaltitudemarketing.com**.
- **Multi‑channel follow‑up sequences** (SMS, Facebook/Instagram DM, email and voicemail) that convert leads to appointments.
- **Automated Google Business Profile posting** and **AI review responses**.
- **Three campaign ads** preloaded for immediate Facebook/Instagram launch.
- **Referral program automations** (50 % off first month when a lead successfully refers another business).

---

## 🚀 How to Import and Activate

1. **Log into HighLevel**. Make sure you’re in the agency view.
2. **Navigate to** `Settings → Snapshots`.
3. Click **Upload Snapshot**, choose `SAM_Snapshot.json` and upload.
4. When prompted, select your **Schott Altitude Marketing** location and click **Install/Restore**. This will recreate workflows, pipelines and automations.
5. HighLevel will ask if you want to import workflows, triggers, emails, funnels etc. Select **Yes** for everything.
6. After import, go to **Integrations** and confirm your existing Google Business Profile, Facebook, Instagram and LinkedIn accounts are connected.
7. In **Phone Numbers**, set **(970) 601‑7803** as your main outbound line and **303‑513‑7795** as the notification number for new leads.
8. Turn on your workflows:
   - **New Lead → Instant Response**
   - **Multi‑Channel Follow‑Up**
   - **Missed Call → Text Back**
   - **Booking & Onboarding Sequences**
   - **Review → Reply → Referral Program**
9. Visit **Social Planner**. You should see 90 days of posts already scheduled for Facebook, Instagram, LinkedIn and Google Business Profile. Check the first week and ensure it looks correct.
10. **Test the system**: submit a lead via your website or form. Verify that you receive an SMS at **303‑513‑7795**, an email at **jason@schottaltitudemarketing.com**, and that the lead appears in your pipeline. Confirm the lead receives the welcome video and follow‑up messages.
11. When you’re ready to run ads, go to **Ads** in HighLevel, open the drafts and click **Launch** for any of the preloaded campaigns.

---

## 👍 Next Steps

- **Monitor performance**: use the built‑in reporting dashboard to track leads, booked calls, reviews and social engagement. Adjust workflows or content as necessary.
- **Duplicate success**: once SAM is running smoothly, you can replicate the same framework for TLCscapes (Tim) and The Voice In You (Kimberly). Those snapshots will have their own forms, branding, voice and target audiences.
- **Optimize**: consider tweaking the follow‑up messaging, ad copy or posting frequency based on your business goals and engagement metrics.

If you need to make changes to scripts, automations or content, you can do so within your HighLevel account after import.

Enjoy your fully‑automated AI marketing system!
